class PhotoCarousel extends HTMLElement {
    // TODO